# Ansible Collection - netology.newfile

Documentation for the collection.
